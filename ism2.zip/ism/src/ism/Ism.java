
package ism;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import ui.Menu;

public class Ism extends JFrame{
  
    public static void main(String[] args) {
        
       
        
        Menu menu = new Menu(); 
        menu.setVisible(true);
        menu.getUsers();
        menu.getCategories();
        menu.getProducts();
        
    }
    
}
