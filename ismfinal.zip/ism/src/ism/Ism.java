
package ism;

import javax.swing.JFrame;
import ui.LoginForm;
import ui.Menu;

public class Ism extends JFrame{
  
    public static void main(String[] args) {
        
       
         Menu menu = new Menu(); 
        LoginForm loginform = new LoginForm(); 
        loginform.setVisible(true);
        menu.getUsers();
        menu.getCategories();
        menu.getGroups();
        menu.getProducts();
        
        
    }
    
}
